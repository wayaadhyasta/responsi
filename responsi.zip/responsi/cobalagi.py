# Combined Python File with Full CRUD Features
import mysql.connector
import tkinter as tk
from tkinter import ttk, messagebox
from datetime import date

# Database Connection
def connect_db():
    return mysql.connector.connect(
        host="localhost",
        user="root",
        database="db_responsi"
    )

# CRUD Operations for Produk
class Produk:
    @staticmethod
    def create(nama, harga):
        conn = connect_db()
        cursor = conn.cursor()
        cursor.execute("INSERT INTO produk (nama_produk, harga_produk) VALUES (%s, %s)", (nama, harga))
        conn.commit()
        conn.close()

    @staticmethod
    def read():
        conn = connect_db()
        cursor = conn.cursor()
        cursor.execute("SELECT * FROM produk")
        results = cursor.fetchall()
        conn.close()
        return results

    @staticmethod
    def update(id_produk, nama, harga):
        conn = connect_db()
        cursor = conn.cursor()
        cursor.execute("UPDATE produk SET nama_produk = %s, harga_produk = %s WHERE id_produk = %s", (nama, harga, id_produk))
        conn.commit()
        conn.close()

    @staticmethod
    def delete(id_produk):
        conn = connect_db()
        cursor = conn.cursor()
        cursor.execute("DELETE FROM produk WHERE id_produk = %s", (id_produk,))
        conn.commit()
        conn.close()

# CRUD Operations for Transaksi
class Transaksi:
    @staticmethod
    def create(id_produk, jumlah, total_harga, tanggal):
        conn = connect_db()
        cursor = conn.cursor()
        cursor.execute(
            "INSERT INTO transaksi (id_produk, jumlah_produk, total_harga, tanggal_transaksi) VALUES (%s, %s, %s, %s)",
            (id_produk, jumlah, total_harga, tanggal)
        )
        conn.commit()
        conn.close()

# GUI
def main_window():
    root = tk.Tk()
    root.title("Aplikasi Manajemen Produk dan Transaksi")

    # Produk Frame
    produk_frame = tk.LabelFrame(root, text="Manajemen Produk")
    produk_frame.grid(row=0, column=0, padx=10, pady=10)

    tk.Label(produk_frame, text="Nama Produk:").grid(row=0, column=0)
    nama_produk = tk.Entry(produk_frame)
    nama_produk.grid(row=0, column=1)

    tk.Label(produk_frame, text="Harga Produk:").grid(row=1, column=0)
    harga_produk = tk.Entry(produk_frame)
    harga_produk.grid(row=1, column=1)

    def tambah_produk():
        try:
            Produk.create(nama_produk.get(), float(harga_produk.get()))
            messagebox.showinfo("Sukses", "Produk berhasil ditambahkan!")
            muat_produk()
        except Exception as e:
            messagebox.showerror("Error", str(e))

    def edit_produk():
        try:
            selected = produk_list.selection()[0]
            values = produk_list.item(selected, 'values')
            id_produk = values[0]
            Produk.update(id_produk, nama_produk.get(), float(harga_produk.get()))
            messagebox.showinfo("Sukses", "Produk berhasil diperbarui!")
            muat_produk()
        except Exception as e:
            messagebox.showerror("Error", str(e))

    def hapus_produk():
        try:
            selected = produk_list.selection()[0]
            values = produk_list.item(selected, 'values')
            id_produk = values[0]
            Produk.delete(id_produk)
            messagebox.showinfo("Sukses", "Produk berhasil dihapus!")
            muat_produk()
        except Exception as e:
            messagebox.showerror("Error", str(e))

    tk.Button(produk_frame, text="Tambah Produk", command=tambah_produk).grid(row=2, column=0)
    tk.Button(produk_frame, text="Edit Produk", command=edit_produk).grid(row=2, column=1)
    tk.Button(produk_frame, text="Hapus Produk", command=hapus_produk).grid(row=2, column=2)

    # Daftar Produk
    produk_list = ttk.Treeview(produk_frame, columns=("ID", "Nama", "Harga"), show="headings")
    produk_list.heading("ID", text="ID")
    produk_list.heading("Nama", text="Nama Produk")
    produk_list.heading("Harga", text="Harga Produk")
    produk_list.grid(row=3, column=0, columnspan=3)

    def muat_produk():
        for item in produk_list.get_children():
            produk_list.delete(item)
        for produk in Produk.read():
            produk_list.insert("", "end", values=produk)

    muat_produk()

    # Transaksi Frame
    transaksi_frame = tk.LabelFrame(root, text="Proses Transaksi")
    transaksi_frame.grid(row=1, column=0, padx=10, pady=10)

    tk.Label(transaksi_frame, text="Pilih Produk:").grid(row=0, column=0)
    produk_dropdown = ttk.Combobox(transaksi_frame)
    produk_dropdown.grid(row=0, column=1)

    def muat_dropdown_produk():
        produk = Produk.read()
        produk_dropdown["values"] = [f"{p[1]} (ID: {p[0]})" for p in produk]

    tk.Button(transaksi_frame, text="Muat Produk", command=muat_dropdown_produk).grid(row=1, column=0, columnspan=2)

    tk.Label(transaksi_frame, text="Jumlah:").grid(row=2, column=0)
    jumlah_produk = tk.Entry(transaksi_frame)
    jumlah_produk.grid(row=2, column=1)

    def tambah_transaksi():
        try:
            jumlah = int(jumlah_produk.get())
            if jumlah <= 0:
                raise ValueError("Jumlah harus positif")

            selected = produk_dropdown.get()
            id_produk = int(selected.split("ID: ")[1][:-1])
            produk = Produk.read()
            harga = next(p[2] for p in produk if p[0] == id_produk)
            total_harga = harga * jumlah
            Transaksi.create(id_produk, jumlah, total_harga, date.today())
            messagebox.showinfo("Sukses", "Transaksi berhasil ditambahkan!")
        except ValueError as ve:
            messagebox.showerror("Validasi Error", str(ve))
        except Exception as e:
            messagebox.showerror("Error", str(e))

    tk.Button(transaksi_frame, text="Tambah Transaksi", command=tambah_transaksi).grid(row=3, column=0, columnspan=2)

    root.mainloop()

# Main Entry Point
if __name__ == "__main__":
    main_window()
